from distutils.core import setup

setup(
    name='TFEBackup',
    version='0.1dev',
    author="Dave Arnold",
    author_email="darnold@hashicorp.com",
    packages=['tfe_backup',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README').read(),
)
