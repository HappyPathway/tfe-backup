# TFE_WorkspaceBackup
This tool provides the ability to backup terraform enterprise workspaces.
It will use the TFE Rest API and collect data about your workspaces, then using templates, will create proper terraform configurations to allow you to rebuild the workspaces.
